<?php
 define('HOST','localhost');
 define('USER','id13373289_resto');
 define('PASS','KkmsFy@yCXQNC2V!');
 define('DB','id13373289_restoran');

 $con = new mysqli(HOST,USER,PASS,DB) or die('Unable to Connect');
 ?>